<br> Welcome to my ecommerce-web app, to run the program clone the repo, open your terminal while you are in the vscode prompt and run "npm start" , then click on the local host link and you are good to go!
<br> Also , the project will not work without the .env file, create it in the ewa_backend directory and add this to it: 
<br> PORT=5000 <
 <br> DB_URI=mongodb+srv://alexborzza:pibmewanr1@cluster0.w7ujeto.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0 
 <br> BASE_URL = http://localhost:5173/  
 <br> HOST = smtp.gmail.com 
 <br> SERVICE = gmail 
<br> EMAIL_PORT = 587 
<br> SECURE = false 
<br> USER = ewa.verifymail@gmail.com 
<br> PASS = adap qiea ayxe xtsw 
<br> JWT_SECRET=ardeo 
<br> STRIPE_SECRET_KEY=sk_test_51PM4JAJVBSSkhR5YX4cLn2nte3Okt9vsad7gjyfF1H02kJe79PsPYuXZMAJhpaCK7iGCX1J42nciPFRsSWly4ujc009rYxPjf4 
